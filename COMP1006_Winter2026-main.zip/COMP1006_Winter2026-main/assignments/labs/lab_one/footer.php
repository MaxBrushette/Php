<?php
// footer.php
// Shared footer content. Included from index.php.
?>
  <hr>
  <p>COMP1006 - Week 2 Lab</p>
</body>
</html>