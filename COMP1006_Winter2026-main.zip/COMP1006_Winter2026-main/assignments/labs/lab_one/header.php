<?php
// header.php
// This file holds shared page header HTML.
// We include/require it from index.php to avoid repeating code.
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>COMP1006 - Lab 1</title>
</head>
<body>
  <h1>COMP1006 - Lab 1</h1>
  <p>Week 2: PHP OOP + Includes + PDO Connection</p>
  <hr>
