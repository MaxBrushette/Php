//1. Set Up & Start 


//2. Code Commenting 


//3. Variables, Data Tyoes, Concatenation, Conditional Statements & Echo


//4. Loosely Typed Language Demo


//5. Strict Types & Types Hints


//6. OOP with PHP 
